    /*=== Slick slider js ===*/
$('.slider-main-for-all-three').slick({
    infinite: true,
    dots: false,
    arrows: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    nextArrow: '<div class="slick-custom-arrow slick-custom-arrow-right"><i class="fas fa-angle-right"></i></div>',
    prevArrow: '<div class="slick-custom-arrow slick-custom-arrow-left"><i class="fa fa-angle-left"></i></div>',

    /*=== Responsive slider icon arrow js ===*/
    responsive: [
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                autoplay: true,
                arrows: false,
                dots: true,
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: true,
                arrows: false,
                dots: true,
            }
        }
    ]
});

/*=== PopUp js ===*/
$('.open-popup-link').magnificPopup({
    type: 'inline',
    midClick: true,
    mainClass: 'mfp-fade'
});

/*=== slider-read-more, read-less js ===*/
// $(document).ready(function () {
//     $(".read-more-btn").click(function () {
//         var elem = $(".read-more-btn").text();
//         if (elem == "Read More") {

//             $(".read-more-btn").text("Read Less");
//             $("#text").slideDown();
//         } else {

//             $(".read-more-btn").text("Read More");
//             $("#text").slideUp();
//         }
//     });
// });

/*=== slider-read-more, read-less js ===*/
$(document).on('click', '.moreless-button', function () {
    $('.moretext').slideToggle();
    if ($(this).text() == "Read more") {
        $(this).text("Read less");
    } else {
        $(this).text("Read more");
    }
});

/*=== hamberg menu js ===*/
$(".mobile-menu1").click(function () {
    $(".mobile-menu").toggleClass("show_sidebar");
});

/*=== Aos js ===*/
$('.stat-number').each(function () {
    var size = $(this).text().split(".")[1] ? $(this).text().split(".")[1].length : 0;
    $(this).prop('Counter', 0).animate({
        Counter: $(this).text()
    }, {
        duration: 5000,
        step: function (func) {
            $(this).text(parseFloat(func).toFixed(size));
        }
    });
});
// function home() { location.replace("/#our-specialize") }






